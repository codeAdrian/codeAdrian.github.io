
robot.n=6;


ksi=[1 1 1 1 1 1];

q=[pi/2 -pi/2 pi/2 0 0 pi];
d=[0 0 0 1320 0 670];
a=[0 1050 -250 0 0 0];
alpha=[-pi/2 0 pi/2 -pi/2 pi/2 0];

for i=1:robot.n
    robot.L(i).ksi=ksi(i);
end

robot.L(1).B=[-50 220 0 400 760 400
                0 0 0 50 50 50];

robot.L(2).B=[-565 0 0 1290 300 570
               0 0 0 50 50 50];

robot.L(3).B=[100 0 0 500 570 439
              0 0 0 50 50 50];
  
robot.L(4).B=[0 625 0 200 1450 200
              0 0 0 50 50 50];

robot.L(5).B=[0 0 85 270 270 270];

robot.L(6).B=[ 0 0 -425 400 400 50
                130 0 -200 70 200 400
               -130 0 -200 70 200 400];

robot.g=[0 0 -9810]';
    
DH=[q' d' a' alpha'];



for i=1:robot.n
   robot.L(i).DH=DH(i,:);
end





