close all;
clear all;
clc;

xmin=1500;
xmax=2000;
zT0=0;
method='corners';
rvsim