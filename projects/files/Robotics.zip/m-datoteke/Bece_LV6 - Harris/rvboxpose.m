
function TA0est = rvboxpose(P,f,TC0,zC,c)

t_x1=P(1,1);
t_y1=P(2,1);
t_x2=P(1,2);
t_y2=P(2,2);
t_x3=P(1,3);
t_y3=P(2,3);
t_x4=P(1,4);
t_y4=P(2,4);

duljina(1)=sqrt((t_x2-t_x1)^2+(t_y2-t_y1)^2); %udaljenost 1. i 2. to�ke
duljina(2)=sqrt((t_x3-t_x2)^2+(t_y3-t_y2)^2); %udaljenost 2. i 3. to�ke
duljina(3)=sqrt((t_x4-t_x3)^2+(t_y4-t_y3)^2); %udaljenost 3. i 4. to�ke
duljina(4)=sqrt((t_x4-t_x1)^2+(t_y4-t_y1)^2); %udaljenost 4. i 1. to�ke
duljina(5)=sqrt((t_x3-t_x1)^2+(t_y3-t_y1)^2); %udaljenost 1. i 3. to�ke
duljina(6)=sqrt((t_x2-t_x4)^2+(t_y2-t_y4)^2); %udaljenost 2. i 4. to�ke

gr_low=70;
x_sr=(t_x1+t_x2+t_x3+t_x4)/4
y_sr=(t_y1+t_y2+t_y3+t_y4)/4

if duljina(1)<gr_low
k1=(t_y2-t_y1)/(t_x2-t_x1);
kut=atan(k1);
end;

if duljina(2)<gr_low
k1=(t_y3-t_y2)/(t_x3-t_x2);
kut=atan(k1);
end;

if duljina(3)<gr_low
k1=(t_y4-t_y3)/(t_x4-t_x3);
kut=atan(k1);
end;

if duljina(4)<gr_low
k1=(t_y4-t_y1)/(t_x4-t_x1);
kut=atan(k1);
end;

if duljina(5)<gr_low
k1=(t_y3-t_y1)/(t_x3-t_x1);
kut=atan(k1);
end;

if duljina(6)<gr_low
k1=(t_y2-t_y4)/(t_x2-t_x4);
kut=atan(k1);
end;

ca=cos(kut-pi/2);
sa=sin(kut-pi/2);

Czi=zC-c/2;

XACest=[(Czi*(x_sr-320))/f;(Czi*(y_sr-240))/f; Czi];

RACest=[ca -sa 0;
        sa ca 0;
        0 0 1];

TACest = [RACest XACest; 0 0 0 1];

TA0est=TC0*TACest;


