function [uc, xNew] = roboctrlalg(robot, ctrlparam, t, q, dq, F, qr, dqr, ddqr, x)



robot = dynmodel(robot,q,dq,0);


for i = 1:robot.n    
    ep(i) = qr(i) - q(i);
    dep(i) = dqr(i) - dq(i);

    if robot.L(i).ksi == 1
        if ep(i) > pi
            ep(i) = ep(i) - 2*pi;
        elseif ep(i) < -pi
            ep(i) = ep(i) + 2*pi;
        end
    end
end
ep = ep';
dep = dep';


uc = robot.D * (ddqr + ctrlparam.KV * dep + ctrlparam.KP * ep) + robot.N + robot.h;

xNew = x;
 
















% 
% %********* Added 20090528 *************
% if ctrlparam.bCartesian == 1
%     wr = qr;
%     dwr = dqr;
%     ddwr = ddqr;
% end
% 
% Fp = x;
% 
% robot = dynmodel(robot,q,dq,0);
% 
% robot = jacobian(robot, q);     
% 
% R = robot.L(robot.n).T(1:3,1:3);
% 
% w = robot.L(robot.n).T(1:3,4);
% 
% J = R * robot.J(1:3,1:robot.n);
% 
% dw = J*dq;
% %**************************************
% 
% 
% 
% if ctrlparam.bCartesian == 1
%     invJ = inv(J);
% 
%     Dw = invJ'*robot.D*invJ;
% else
%     for i = 1:robot.n    
%         ep(i) = qr(i) - q(i);
%         dep(i) = dqr(i) - dq(i);
% 
%         if robot.L(i).ksi == 1
%             if ep(i) > pi
%                 ep(i) = ep(i) - 2*pi;
%             elseif ep(i) < -pi
%                 ep(i) = ep(i) + 2*pi;
%             end
%         end
%     end
%     ep = ep';
%     dep = dep';
% end
% 
% 
% %Original - commented 20090528
% %uc = ctrlparam.Dn * (ddqr + ctrlparam.KV * dep + ctrlparam.KP * ep);
% 
% switch ctrlparam.type
%      
%      case 'PD'  % PD regulator
%          uc = robot.D * (ddqr + ctrlparam.KV * dep + ctrlparam.KP * ep);
%          
%          xNew = x;
%          
% %      case 'PDg' % PD regulator + kompenzacija gravitacijskog djelovanja
% %          uc = robot.D * (ddqr + ctrlparam.KV * dep + ctrlparam.KP * ep); % + robot.h;
% %          
% %          xNew = x;
%          
%      case 'PID' % PID  regulator
%          xNew = x + ep*ctrlparam.T;
%          uc = robot.D * (ddqr + 70*dep + 1100*ep + 5000*xNew);
%           
%      case 'EstP' % Estimacija poreme�aja
%          
%          
%          %x[1:6] - past values of uc
%          %x[7:12] - past values of u
%          %x[13:18] - past values of q
%          
%          uc_1 = x(1:6);
%          uk_1 = x(7:12);
%          qk_1 = x(13:18);
%          
%          uk = robot.D * (ddqr + ctrlparam.KV * dep + ctrlparam.KP * ep);
%          
%          uc = uc_1 + (1 + ctrlparam.T/ctrlparam.TimeConstant)*uk  -  uk_1  -  (robot.D*(q - qk_1)/ctrlparam.TimeConstant);
%          
%          xNew = [uc;uk;q];
%          
%          
% %          %x[1:6] - past values of uc
% %          %x[7:12] - past values of u
% %          %x[13:18] - past values of q
% %          
% %          uc_1 = x(1:6);
% %          uk_1 = x(7:12);
% %          qk_1 = x(13:18);
% %          
% %          a = exp()
% %          u = robot.D * (ddqr + ctrlparam.KV * dep + ctrlparam.KP * ep);
% %          
% %          uc = uc_1 + (1 + ctrlparam.TimeConstant/ctrlparam.T)*uk  -  uk_1  -  (robot.D*(q - qk_1)/ctrlparam.T);
% %          
% %          xNew = [uc;uk;q];
%    
%     case 'HFP'  % hybrid force-position control
%          if t > ctrlparam.t1 && t < ctrlparam.t2
%             S = [1 0 0; 0 0 0; 0 0 0];
%         else
%             S = zeros(3,3);
%          end    
% 
%         ucp = ctrlparam.KP*(wr-w) + ctrlparam.KV*(dwr - dw) + ddwr;
% 
%         Fs = -F(1:3);
% 
%         ucf = ctrlparam.KF*(ctrlparam.Fr - Fs) - ctrlparam.KV*dw;
% 
%         ucfp = (eye(3) - S) * ucp + S * ucf;
% 
%         uc = J' * (Dw * ucfp + S * ctrlparam.Fr);
%         
%         xNew = x;
%         
%     case 'IMP'  % Impedance control
%         
%         Fs = -F(1:3);
% 
%         %     for i = 1:3
%         %         if Fs(i) > 50
%         %             Fs(i) = 50;
%         %         elseif Fs(i) < -50
%         %             Fs(i) = -50;
%         %         end
%         %     end
% 
%         Fr = ctrlparam.KP * (wr-w)+ ctrlparam.KD * (dwr-dw);
% 
%         dF = (Fs - Fp)/ctrlparam.T;
% 
%         %uc = J' * (Fs + Dw * (ctrlparam.KF*(Fr-Fs)-ctrlparam.KFD*dw));
%         uc = J' * (Fs + Dw * ctrlparam.KF*(Fr-Fs));
%         %uc = J' * Dw * ctrlparam.KF*(Fr-Fs);
%             
%         xNew = x;
%         
%      otherwise   % default CTC - Computed Torque Control
%          uc = robot.D * (ddqr + ctrlparam.KV * dep + ctrlparam.KP * ep) + robot.N + robot.h;
%          xNew = x;
%  end
% 
% if ctrlparam.bGravComp == 1
%     uc = uc + robot.h;
% end
% 
% %xNew = x;

