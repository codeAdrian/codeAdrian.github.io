%OSNOVE ROBOTIKE LV: OPIS MANIPULATORA
%E. Karlo Nyarko
%20.3.2012.

%Helper file


%broj osi robota
robot.n=6;

%tip zgloba 
%(0->translacijski 1->rotacijski)
ksi=[1 1 1 1 1 1];

%kinematicki parametri  q (theta)-parametri zglobova
q=[pi/2 -pi/2 pi/2 0 0 -pi/2];  
d=[0 0 0 300 0 150];
a=[0 240 0 0 0 0];
alpha=[-pi/2 0 pi/2 -pi/2 pi/2 0];



for i=1:robot.n
    robot.L(i).ksi=ksi(i);
end


robot.L(1).B=[0 120 0 60 300 60];
          
robot.L(2).B=[-120 0 60 300 60 60];

robot.L(3).B=[0 0 120 60 60 300];

robot.L(4).B=[0 10 0 20 40 20];

robot.L(5).B=[0 20 10 20 20 40
              0 -20 10 20 20 40
              0 0 50 60 60 40];

robot.L(6).B=[0 0 -60 20 20 40
              0 0 -35 30 100 10
              0 35 -15 20 10 30
              0 -35 -15 20 10 30];


robot.g=[0 0 -9810]';
    

DH=[q' d' a' alpha'];


for i=1:robot.n
   robot.L(i).DH=DH(i,:);
end



% a = 60; b = 300;
% m = 2700*a^2*b*1e-9;
% robot.L(1).m = m;
% robot.L(1).dc = [0 120 0]';
% robot.L(1).Dc = m*[(a^2+b^2)/12 0 0; 0 2*a^2/12 0; 0 0 (a^2+b^2)/12];
% 
% robot.L(2).m = m;
% robot.L(2).dc = [-120 0 60]';
% robot.L(2).Dc = m*[2*a^2/12 0 0; 0 (a^2+b^2)/12 0; 0 0 (a^2+b^2)/12];
% 
% robot.L(3).m = m;
% robot.L(3).dc = [0 0 120]';
% robot.L(3).Dc = m*[(a^2+b^2)/12 0 0; 0 (a^2+b^2)/12 0; 0 0 2*a^2/12];
% 
% robot.L(4).m = 2700*0.02^2*0.04;
% robot.L(4).dc = [0 10 0]';
% robot.L(4).Dc = robot.L(4).m*[(20^2+40^2)/12 0 0; 0 (20^2+20^2)/12 0; 0 0 (20^2+20^2)/12];
% 
% robot.L(5).m = 2700*0.06^2*0.04;
% robot.L(5).dc = [0 0 50]';
% robot.L(5).Dc = robot.L(5).m*[(60^2+40^2)/12 0 0; 0 (60^2+40^2)/12 0; 0 0 (60^2+60^2)/12];
% 
% robot.L(6).m = 2700*0.03*0.1*0.01;
% robot.L(6).dc = [0 0 -35]';
% robot.L(6).Dc = robot.L(6).m*[(100^2+10^2)/12 0 0; 0 (30^2+10^2)/12 0; 0 0 (100^2+30^2)/12];
% 
% robot.bInit = 0;



