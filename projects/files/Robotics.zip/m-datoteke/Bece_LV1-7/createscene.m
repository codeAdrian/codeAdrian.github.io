function[robot,plotbox,alpha,beta]=createscene()
createRobotLV3;
plotbox=[-1000 2400 -1000 1100 -500 1800];
alpha = 145;
beta = 30;