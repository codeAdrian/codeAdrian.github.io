function [x, y]=ellipse(P, x0, y0);

[x, y] = ellipse2(P, x0, y0, 0.001);
