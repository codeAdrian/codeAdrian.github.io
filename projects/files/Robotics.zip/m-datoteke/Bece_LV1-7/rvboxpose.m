
function TA0est = rvboxpose(P,f,TC0,zC,c)
iE(1)=1;
iE(3)=-1;

for i=2:4
    if abs(P(1,i)-P(1,1))<10*pi/180
        iE(2)=i;
    elseif iE(3) ==-1
        iE(3)=i;
    else
        iE(4)=i;
    end
end

if abs (P(2,iE(1))-P(2,iE(2)))>abs(P(2,iE(3))-P(2,iE(4)))
    iTmp=iE(1);
    iE(1)=iE(3);
    iE(3)=iTmp;
    iTmp=iE(2);
    iE(2)=iE(4);
    iE(4)=iTmp;
end

alphaest=P(1,iE(3));
Uest=[0 0]';

for i=1:2
    for j=3:4
        Uest=Uest + inv([cos(P(1,iE(i))) sin(P(1,iE(i)));...
            cos(P(1,iE(j))) sin(P(1,iE(j)))])*...
            [P(2,iE(i));P(2,iE(j))];
    end
end
Uest=0.25*Uest;

XACest = [Uest*(zC-c)/f; zC-c/2];

ca=cos(alphaest);
sa=sin(alphaest);

RACest=[ca -sa 0;
        sa ca 0;
        0 0 1];

TACest = [RACest XACest; 0 0 0 1];

TA0est=TC0*TACest;





