close all;
clear all;
clc;

createRobotLV3; 

Wr =[0 2200 0;
    50 2200 200;
    100 2200 400;
    125 2200 500;
    150 2200 600;
    175 2200 700;
    200 2200 800;
    250 2200 1000;
    300 2200 1200;
    350 2200 1400;
    400 2200 1200;
    450 2200 1000;
    500 2200 800;
    550 2200 600;
    600 2200 400;
    650 2200 200;
    700 2200 0;
    650 2200 200;
    600 2200 400;
    550 2200 600;
    400 2200 600;
    300 2200 600;
    150 2200 600;
    125 2200 500;
    100 2200 400;
    0 2200 0]';

m = length(Wr);

T60(:,:,1) = [1 0 0 Wr(1,1);
              0 0 1 Wr(2,1); 
              0 -1 0 Wr(3,1);
              0 0 0 1];

for i = 2:m-1
    T60(:,:,i) = [1 0 0 Wr(1,i); 
                  0 0 1 Wr(2,i); 
                  0 -1 0 Wr(3,i); 
                  0 0 0 1];
end

T60(:,:,m) = [1 0 0 Wr(1,m); 
              0 0 1 Wr(2,m); 
              0 -1 0 Wr(3,m);
              0 0 0 1];

Q = [];

for i = 1:m
    if i==1
        Q=[Q invkin(T60(:,:,i))];
    else
        Q=[Q invkin(T60(:,:,i),Q(:,end))];
    end
    

    if i > 1
        for j = 1:6
            if Q(j,i) - Q(j,i-1) > pi
                Q(j,i) = Q(j,i) - 2 * pi;
            else
                if Q(j,i) - Q(j,i-1) < -pi
                   Q(j,i) = Q(j,i) + 2 * pi;
                end
            end
        end
    end
end

Q = [Q; zeros(1, m)];

dqgr = [15 15 15 15 15 15 1000]'; 
ddqgr = [25 25 25 25 25 25 1000]';

[Qc, dQc, ddQc] = hocook(Q, dqgr, ddqgr, 0.002); 
nt = length(Qc); 

N = [0 1 0]'; 
d = 2200; 

W = [];

for k = 1:nt
    robot = dirkin(robot,Qc(1:6,k)); 
    W = [W robot.L(robot.n).T(1:3,4)];
end

figure(1)
plot(Qc(8,:)',Qc(1:6,:)') 

figure(2)
plot(Qc(8,:)',dQc(1:6,:)') 
figure(3)
plot(Qc(8,:)',ddQc(1:6,:)')

figure(4)

dyn3dscene(robot, Qc, [], [-600 800 -600 1900 -1300 2200], 145, -30, 0.05,0.001)

hold on

plot3(W(1,:),W(2,:),W(3,:),'g',Wr(1,:),Wr(2,:),Wr(3,:),'ro'),axis equal


hold off

figure(5)

planecontact(W,N,d)

