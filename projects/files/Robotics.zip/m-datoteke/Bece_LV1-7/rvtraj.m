function[Qc,TA0est]=rvtraj(P,f,TT0,TCT,c)
createRobotLV3;
TC0=TT0*TCT;
TA0est=rvboxpose(P,f,TC0,TCT(3,4),c);

T60(:,:,1)=[1 0 0 0; 
            0 1 0 0; 
            0 0 1 2000;
            0 0 0 1]; 

T6A=[1 0 0 0; 
     0 1 0 0;
     0 0 1 100;
     0 0 0 1];
 
 T60(:,:,2)=TA0est*T6A;
 
 T6A=[1 0 0 0;
     0 1 0 0;
     0 0 1 0;
     0 0 0 1];
 
 T60(:,:,3)=TA0est*T6A;
      
m=3;
Q = [];

for i = 1:m
    
    if i==1
        Q=[Q invkin(T60(:,:,i))];
    else
        Q=[Q invkin(T60(:,:,i),Q(:,end))];
    end
    

    if i > 1
        for j = 1:6
            if Q(j,i) - Q(j,i-1) > pi
                Q(j,i) = Q(j,i) - 2 * pi;
            else
                if Q(j,i) - Q(j,i-1) < -pi
                   Q(j,i) = Q(j,i) + 2 * pi;
                end
            end
        end
    end
end

Q = [Q;50 50 50];

dqgr = [16 16 16 16 16 16 100]'; 
ddqgr = [25 25 25 25 25 25 10000]'; 

[Qc, dQc, ddQc] = hocook(Q, dqgr, ddqgr, 0.002); 
nt = length(Qc); 

N = [1 0 0]'; 
d = 500; 

W = [];

for k = 1:nt
    robot = dirkin(robot,Qc(1:6,k));
    W = [W robot.L(robot.n).T(1:3,4)];
end
