function q = invkin(T60,qPrev) 

p = T60 * [0 0 -670 1]';

x = p(1);
y = p(2);
z = p(3);
r=x^2+y^2+z^2;
a1=0;
a2=1050;
a3=-250;

u3= roots([3432400-r 5544000 2382400-r]);

Q = [];

for i=1:2
    q3 = 2 * atan(u3(i));
    
    s3=sin(q3);
    c3=cos(q3);
    
    f1=1320*s3-250*c3+1050;
    f2=-250*s3-1320*c3;
    
    u2 = roots([z-f2 2*f1 f2+z]);
    
    for k=1:2
       q2 = 2 * atan(u2(k));

        c2 = cos(q2);
        s2 = sin(q2);

        g1 = c2*f1-s2*f2;
        g2=0;

        q1 = atan2(-g2*x+g1*y,g1*x+g2*y);
        
%       d=[0 0 0 1320 0 670];
%       a=[0 1050 -250 0 0 0];
%       alpha=[-pi/2 0 pi/2 -pi/2 pi/2 0];

        T10 = dhtransf([q1 0 a1 -pi/2]);
        T21 = dhtransf([q2 0 a2 0]);
        T32 = dhtransf([q3 0 a3 pi/2]);
        T30 = T10*T21*T32;
        R30 = T30(1:3,1:3);
        R60 = T60(1:3,1:3);
        R63 = R30'*R60;

        for j=1:2
            if j == 1
                q5 = acos(R63(3,3));
            else
                q5 = -acos(R63(3,3));
            end

            s5 = sin(q5);

            if s5 == 0
                q4 = 0;
                q6 = acos(R63(1,1));
            else
                q4 = atan2(R63(2,3)/s5, R63(1,3)/s5);
                q6 = atan2(R63(3,2)/s5, -R63(3,1)/s5);
            end

            q = [q1, q2, q3, q4, q5, q6]';
            
            Q = [Q q];
        end

    end
end

if nargin == 1      
    q = [];
    for i=1:5
        if Q(3,i) > 0
            q = Q(:,i);
            break
        end  
    end
    
    for i=1:5
        if Q(1,i) > 0
            q = Q(:,i);
            break
        end  
    end
        
    if isempty(q)
        q = Q(:,1);
    end
else
    dQ = Q-qPrev*ones(1,8);
    
    for i=1:6
        for j=1:8
            if dQ(i,j) > pi
                dQ(i,j) = dQ(i,j) - 2*pi;
            else
                if dQ(i,j) < -pi
                    dQ(i,j) = dQ(i,j) + 2*pi;
                end
            end
        end
    end
    
    [tmp, i] = min(max(abs(dQ)));    

    q = qPrev + dQ(:,i);
end


