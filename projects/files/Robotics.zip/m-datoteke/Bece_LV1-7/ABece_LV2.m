close all;
clear all;
clc;

A=190; B=1500; C=400; 
X0A=[0 1200 -700]';
alphaA=0;

ca = cos(alphaA);
sa = sin(alphaA);

RA0 = [ca -sa 0
       sa ca 0
       0 0 1];   
   
TA0 = [RA0 X0A; 0 0 0 1]; 

T6A=[1 0 0 0;
     0 -1 0 0;
     0 0 -1 -200;
     0 0 0 1];

T60=TA0*T6A;

createRobot; 

q=invkin(T60)';

DH=[q' d' a' alpha'];

for i=1:robot.n
   robot.L(i).DH=DH(i,:);
end

robmesh = robotmesh(robot, q);

plot3dobj(robmesh);

Tbase=[1 0 0 0
       0 1 0 -280
       0 0 1 -750 
       0 0 0 1];
   
base=cuboid(860,860,300);
base.X= Tbase*base.X;
hold on;
plot3dobj(base);


T = eye(4);
for i = 1:robot.n
    pDH = robot.L(i).DH;
    T = T * dhtransf(pDH);
end

TA6= [1 0 0 0;
      0 -1 0 0;
      0 0 -1 -200;
      0 0 0 1];
  
TA0new=T*TA6;

obj=cuboid(A,B,C);
obj.X=TA0new*obj.X;
env.object(1)=obj;

hold on;
plot3dobj(obj);




