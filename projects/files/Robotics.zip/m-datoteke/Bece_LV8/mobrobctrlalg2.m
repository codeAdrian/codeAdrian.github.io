% vizualni senzor
% predikcija - na temelju odometrije (sklopovi) + korekcija (pomo�u
% o�itanja vanjskog senzora)
% matrica kovarijance - sadrzi mjerne nesigurnosti
% vr - brzina kretanja (ako je 0 onda se okre�e na mjestu)
% wr - kutna brzina (ako je 0 onda robot ide samo naprijed)
% ako su oba razlicita od 0 onda skre�e
%mem - pohrana podataka izmedju prethodnog i trenutnog koraka

function [UNew,XNew,PNew,memNew]=mobrobctrlalg2(Y,mem,k,Ts,M,Xr,vr,wr)
stdvz=0.02; %standardna devijacija za brzinu i kutnu brzinu
stdwz=2*pi/180;
stduz=1;

EKFparams.Ts=Ts;
EKFparams.Rz=diag([stdwz^2,stdvz^2]); %generira matricu na cijim je dijagonalama o'^2 (kvadrat nesigurnosti)
EKFparams.Ru=stduz^2;
EKFparams.uc=320/2;
EKFparams.f=300;
EKFparams.M=M;
EKFparams.nM=max(size(M));

%EKF

%X-vektor polozaja
%P-matrica polozaja, U-matrica upravljackih signala

%ako je prvi korak
if(k==1)
    X=zeros(3,1);
    U=zeros(2,1);
    P=zeros(3,3);
    [XNew,PNew]=ekf(X,P,U,Y,EKFparams,0,1);
%ako nije prvi korak
else
    X=mem(1:3);
    U=mem(4:5);
    P=[mem(6:8)';mem(9:11)';mem(12:14)'];
    [XNew,PNew]=ekf(X,P,U,Y,EKFparams,1,1);
end

%formule iz pripreme za LV8
alphae=XNew(1);
xe=XNew(2);
ye=XNew(3);

alphar=Xr(1);
xr=Xr(2);
yr=Xr(3);
%funkcija normalangle vra�a od -pi do pi
e = [xr-xe;yr-ye;];
r = sqrt(e'*e);%ro

alphac=atan2(e(2),e(1));

%sigma je o sa crticom, ro je kao p (u dokumentu LV8) i alfa
%ta 3 kuta su potrebna za zakon upravljanja
a=normangle(alphac-alphae);
b=normangle(alphar-alphae);
b=normangle(b-a);

if a>pi
    s=-1; % sigma, vidi u dokumentu
else
    if a<-pi
        s=-1;
    else
        s=1;
    end
end

v=s*0.2*r/Ts+0.5*vr;
w=(0.8*a-0.2*b)/Ts+0.5*wr;

UNew=[v w]';
memNew=[XNew;UNew;PNew(1:3)';PNew(4:6)';PNew(7:9)'];

%parametri regulatora - procjenom se odrede


    