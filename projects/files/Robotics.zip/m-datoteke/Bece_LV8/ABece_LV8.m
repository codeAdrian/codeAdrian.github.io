clear all;
close all;
clc;

multisim=0;
%multisim=1;
camera=1;
%camera=0;
nMultiSimulations=500;

vr=[]; 
wr=[];

%naprijed
vr=[vr;0.5*ones(18,1)];
wr=[wr;zeros(18,1)];

%polukrug
for i=1:2
vr=[vr;0.5*ones(6,1)];
wr=[wr;15*pi/180*ones(6,1)];
end

%naprijed
vr=[vr;0.5*ones(9,1)];
wr=[wr;zeros(9,1)];

%okret na mjestu za 90
vr=[vr;zeros(6,1)];
wr=[wr;-15*pi/180*ones(6,1)];

% 2x naprijed i okret na mjestu za 90
for i=1:2
vr=[vr;0.5*ones(9,1)];
wr=[wr;zeros(9,1)];

vr=[vr;zeros(6,1)];
wr=[wr;15*pi/180*ones(6,1)];
end

%dolje
vr=[vr;0.5*ones(18,1)];
wr=[wr;zeros(15,1)];

vr=[vr;zeros(20,1)];
wr=[wr;zeros(20,1)];

M=[9,2;
  -1,3;
   5,5;
   2,7.5]';

% M=[-1,3;
%     5,5]';

RV_EKF_sim;
