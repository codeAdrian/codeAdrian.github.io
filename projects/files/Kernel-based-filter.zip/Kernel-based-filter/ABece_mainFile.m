clear all; close all; clc;

%--------------------------- ULAZNI PODACI ---------------------------%
%SLIKA - staviti ju u folder u kojem se nalazi m-daoteka i upisati naziv
slika = imread('peppers.png');
%slika = imread('test.jpg');

% PADDING - metoda paddinga slike
padding='symmetric';
%padding='replicate';
%padding='circular';

%MASKE FILTERA (KERNELI):
%filter = 1/25*[1 1 1 1 1;1 1 1 1 1;1 1 1 1 1;1 1 1 1 1;1 1 1 1 1;]'; % 5x5 blur
%filter = 1/5*[1 1 1 1 1]; % 1x5 blur
%filter = 1/3*[1 1 1]'; % 3x1 blur
filter = 1/9*[1 1 1;1 1 1; 1 1 1]; % 3x3 blur
%filter = [0 -1 0;-1 5 -1; 0 -1 0]; %sharpen
%filter = [-1 -1 -1;-1 8 -1; -1 -1 -1]; % edge detection
%--------------------------------------------------------------------%

f_s=size(filter);
if mod(f_s,2)~=0
    filtrirana_slika=ABece_filter(slika,filter,padding);
    
    %-------------------------PRIKAZ SLIKA -------------------------%
    figure(1);
    subplot(1,2,1),imshow(slika),title('Originalna slika');
    subplot(1,2,2),imshow(filtrirana_slika),title('Rezultat filtera');
    %---------------------------------------------------------------%
else
    fprintf('Matrica mora biti neparnih dimenzija!\n\n');
end;