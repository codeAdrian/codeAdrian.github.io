function [filtrirana_slika]=ABece_filter(originalSlika,filter,padding)

originalSlika = im2double(originalSlika);
originalSlika = RGB2gray(originalSlika);
[x,y] = size(filter); % velicina matrice filtera (za detekciju susjedstva)
susjed_u=(x-1)/2; % koliko susjeda iznad ili ispod od centralnog
susjed_v=(y-1)/2; % koliko susjeda lijevo ili desno od centralnog
velicinaSlike = size(originalSlika); % velicina ucitane slike
filtrirana_slika = zeros(velicinaSlike-susjed_u-1); %oduzima se padding
originalSlika=padarray(originalSlika,[susjed_u,susjed_v],padding);

for u = susjed_u+1:velicinaSlike(1) % nadodaje se zbog paddinga na x
    for v = susjed_v+1:velicinaSlike(2) % nadodaje se zbog paddinga na y
        if(x==1) % ako matrica ima jedan red
            temp = originalSlika(u-susjed_u:u+susjed_u,v) .* filter;
        elseif(y==1) % ako matrica ima jedan stupac
            temp = originalSlika(u,v-susjed_v:v+susjed_v) .* filter;
        else % ako je matrica neparnih dimenzija vecih od 1
            temp = originalSlika(u-susjed_u:u+susjed_u,v-susjed_v:v+susjed_v) .* filter;
        end;
        filtrirana_slika(u-susjed_u,v-susjed_v) = sum(temp(:)); %od brojaca se oduzima odstupanje paddinga
    end;
end;